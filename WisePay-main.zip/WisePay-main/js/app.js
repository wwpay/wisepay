﻿// 수정: 2026-06-13 15:32 — checkAndShowPayrollAlerts 조기 호출 제거 (autoLoadFromGas 완료 후로 이동)
'use strict';

// families(16세 이상) 기반으로 employees의 fuyouCount를 재계산하여 저장
function syncFuyouFromFamilies() {
  let changed = false;
  employees.forEach(emp => {
    const cnt = Math.min((emp.families||[]).filter(f=>{
      if(!f.birth) return false;
      return calcAgeByYear(f.birth) >= 16;
    }).length, 7);
    if((emp.fuyouCount||0) !== cnt) { emp.fuyouCount = cnt; changed = true; }
  });
  if(changed) localStorage.setItem(LS.emp, JSON.stringify(employees));
  return changed;
}
// ══ INIT ══
window.addEventListener('DOMContentLoaded', () => {
  LANG = localStorage.getItem(LS.lang) || 'KR';
  applyLang();
  if (!checkAuth()) return;
  initApp();
});

// GAS 다운로드 후에도 실행 가능한 요율 이력 마이그레이션 함수
// 반환값: GAS 역업로드가 필요한 경우 true
function migrateRateHistory() {
  let migrated = false;
  // 잘못된 항목 제거: 2026-01은 실제 보험료율 변경이 없는 달 (구버전 기본값 잔재)
  const invalidEntries = ['2026-01'];
  const beforeLen = rateHistory.length;
  rateHistory = rateHistory.filter(r => !invalidEntries.includes(r.from));
  if(rateHistory.length !== beforeLen) migrated = true;
  // 오류 값 수정
  rateHistory.forEach(r => {
    if(r.from < '2026-04' && r.kodomo > 0)                      { r.kodomo = 0.00; migrated = true; }
    if(r.from < '2026-04' && Math.abs(r.koyo  - 0.50) < 0.001) { r.koyo   = 0.55; migrated = true; }
    // 2024년도(R6) 건강·개호보험 요율: 이전 버전에서 잘못 보정된 값 복구
    if((r.from === '2024-03' || r.from === '2024-04') && Math.abs(r.kenko - 9.98) > 0.001) { r.kenko = 9.98; migrated = true; }
    if((r.from === '2024-03' || r.from === '2024-04') && Math.abs(r.kaigo - 1.60) > 0.001) { r.kaigo = 1.60; migrated = true; }
    // 2025년도(R7) 건강·개호보험 요율 보정
    if((r.from === '2025-03' || r.from === '2025-04') && Math.abs(r.kenko - 9.91) > 0.001) { r.kenko = 9.91; migrated = true; }
    if((r.from === '2025-03' || r.from === '2025-04') && Math.abs(r.kaigo - 1.59) > 0.001) { r.kaigo = 1.59; migrated = true; }
  });
  // 누락 항목 추가 (변경 시점 기준 전체 이력)
  const defaults = [
    { from:'2024-03', kenko:9.98, kaigo:1.60, kodomo:0.00, nenkin:18.30, koyo:0.60 },
    { from:'2024-04', kenko:9.98, kaigo:1.60, kodomo:0.00, nenkin:18.30, koyo:0.60 },
    { from:'2025-03', kenko:9.91, kaigo:1.59, kodomo:0.00, nenkin:18.30, koyo:0.60 },
    { from:'2025-04', kenko:9.91, kaigo:1.59, kodomo:0.00, nenkin:18.30, koyo:0.55 },
    { from:'2026-03', kenko:9.85, kaigo:1.62, kodomo:0.00, nenkin:18.30, koyo:0.55 },
    { from:'2026-04', kenko:9.85, kaigo:1.62, kodomo:0.23, nenkin:18.30, koyo:0.50 },
  ];
  defaults.forEach(def => {
    if(!rateHistory.find(r => r.from === def.from)) {
      rateHistory.push({...def}); migrated = true;
    }
  });
  // 중복 제거 + 정렬
  const seenFrom = new Set();
  const deduped = [];
  [...rateHistory].sort((a,b)=>a.from>b.from?1:-1).reverse().forEach(r => {
    if(!r.from || !/^\d{4}-\d{2}$/.test(r.from) || seenFrom.has(r.from)) return;
    seenFrom.add(r.from); deduped.unshift(r);
  });
  if(deduped.length !== rateHistory.length) { rateHistory = deduped; migrated = true; }
  else rateHistory.sort((a,b) => a.from > b.from ? 1 : -1);
  if(migrated) localStorage.setItem(LS.rateHistory, JSON.stringify(rateHistory));
  return migrated;
}

function initApp() {
  // load storage
  try { const s = localStorage.getItem(LS.emp); if(s) { employees = JSON.parse(s).filter(e => e && !e.deleted); employees.forEach(e=>{ if(e.shaho_start) e.shaho_start=normalizeYM(e.shaho_start); if(e.join) e.join=normalizeDate(e.join); if(e.leave) e.leave=normalizeDate(e.leave); if(e.birth) e.birth=normalizeDate(e.birth); }); } } catch(e){}
  try { const s = localStorage.getItem(LS.rateHistory); if(s) rateHistory = JSON.parse(s); } catch(e){}
  try { const s = localStorage.getItem(LS.deletedEmpIds); if(s) deletedEmpIds = JSON.parse(s); } catch(e){}
  try { const s = localStorage.getItem(LS.paidYMs);     if(s) paidYMs     = new Set(JSON.parse(s)); } catch(e){}
  try { const s = localStorage.getItem(LS.paidDetails); if(s) paidDetails = JSON.parse(s);           } catch(e){}
  // 마이그레이션
  syncFuyouFromFamilies();
  migrateRateHistory();
  // 구버전 단일 rates 호환
  try { const s = localStorage.getItem(LS.rates); if(s) { const r=JSON.parse(s); rates={...rates,...r}; } } catch(e){}
  // 구버전 급여 키 마이그레이션: 비패딩 사원번호(kyuyo_p_1_...) → 4자리(kyuyo_p_0001_...)
  migratePayrollKeys();
  // GAS URL은 state.js에서 하드코딩 — localStorage에 동기화
  localStorage.setItem(LS.gas, gasUrl);
  document.getElementById('gasUrlInput').value = gasUrl;

  // 급여 입력란: 포커스 이탈 시 빈 값 → "0" 복원
  document.addEventListener('focusout', e => {
    if(e.target.matches('#page-payroll .row-input') && e.target.value === '') {
      e.target.value = '0';
    }
  });

  renderEmpSelect();
  renderMonthTabs();
  applyRatesForYM(currentYear, currentMonth);
  loadPayrollForm();
  renderPaidBtn();
  updateRatesDisplay();
  checkRateBanner();
  updateGasStatus();
  try { buildHistEmpSel(); } catch(e) { console.error('buildHistEmpSel error:', e); }
  try { buildAnnualYearSel(); buildAnnualEmpSel(); } catch(e) { console.error('buildAnnual error:', e); }
  setTimeout(() => onMonthYearChange(), 100);
  // 로그인 후 Google 시트에서 최신 데이터 자동 로드
  autoLoadFromGas();
  // 월요일 접속 시 수동 백업 알림
  checkBackupReminder();
  // 백업 다운로드 후 리로드 시 이전 페이지 복원
  const _rp = sessionStorage.getItem('wisepay_restore_page');
  if (_rp) {
    sessionStorage.removeItem('wisepay_restore_page');
    const _nav = document.querySelector(`.nav-item[data-page="${_rp}"]`);
    setTimeout(() => gotoPage(_rp, _nav), 150);
  }
  if (typeof applyViewerRestrictions === 'function') applyViewerRestrictions();
  if (currentUser && currentUser.id === 'wiseadmin') {
    if (typeof initNotifications === 'function') initNotifications();
    // checkAndShowPayrollAlerts は autoLoadFromGas() 완료 후 호출됨 (gas.js)
  }
}

// 페이지 닫기/새로고침 시 미저장 경고
window.addEventListener('beforeunload', e => {
  if(payrollDirty || empFormDirty) {
    e.preventDefault();
    e.returnValue = '';
  }
});

function savePdf() {
  const jp = LANG === 'JP';
  const activePage = document.querySelector('.page.active')?.id || '';
  let filename = 'WisePay';

  if (activePage === 'page-payroll' && currentEmpIdx >= 0) {
    const emp = employees[currentEmpIdx];
    if (emp) {
      const no = String(emp.no).padStart(4, '0');
      filename = jp
        ? `${no}_${emp.name}_給与明細_${currentYear}年${currentMonth}月`
        : `${no}_${emp.name}_급여명세_${currentYear}년${currentMonth}월`;
    }
  } else if (activePage === 'page-annual') {
    const year = parseInt(document.getElementById('annualYearSel')?.value) || currentYear;
    const nos = (typeof getSelectedAnnualNos === 'function') ? getSelectedAnnualNos() : [];
    if (nos.length === 1) {
      const emp = employees.find(e => parseInt(e.no) === nos[0]);
      if (emp) {
        const no = String(emp.no).padStart(4, '0');
        filename = jp
          ? `${no}_${emp.name}_賃金台帳_${year}年度`
          : `${no}_${emp.name}_임금 대장_${year}년도`;
      }
    } else if (nos.length > 1) {
      const isAll = nos.length === employees.length;
      const prefix = isAll ? (jp ? '全従業員' : '전사원') : '';
      filename = jp
        ? `${prefix ? prefix + '_' : ''}賃金台帳_${year}年度`
        : `${prefix ? prefix + '_' : ''}임금 대장_${year}년도`;
    }
  } else if (activePage === 'page-employees' && editingEmpIdx >= 0) {
    const emp = employees[editingEmpIdx];
    if (emp) {
      const no = String(emp.no).padStart(4, '0');
      filename = jp
        ? `${no}_${emp.name}_従業員情報`
        : `${no}_${emp.name}_사원정보`;
    }
  }

  const origTitle = document.title;
  document.title = filename;
  window.addEventListener('afterprint', () => { document.title = origTitle; }, { once: true });
  window.print();
}

// 인쇄 시 스크롤바 제거 + overflow:hidden 해제 (page-break 동작 보장)
window.addEventListener('beforeprint', () => {
  document.querySelectorAll('.annual-scroll-wrap, .annual-wrap').forEach(el => {
    el.style.overflow = 'visible';
    el.style.minWidth = '0';
  });
  // flex 컨테이너 해제: min-height:100vh가 content 높이를 1페이지로 제한 → 마지막 표 잘림
  const layout = document.querySelector('.layout');
  if (layout) { layout.style.display = 'block'; layout.style.minHeight = '0'; layout.style.height = 'auto'; }
  const content = document.querySelector('.content');
  if (content) { content.style.overflow = 'visible'; content.style.height = 'auto'; }
});
window.addEventListener('afterprint', () => {
  document.querySelectorAll('.annual-scroll-wrap, .annual-wrap').forEach(el => {
    el.style.overflow = '';
    el.style.minWidth = '';
  });
  const layout = document.querySelector('.layout');
  if (layout) { layout.style.display = ''; layout.style.minHeight = ''; layout.style.height = ''; }
  const content = document.querySelector('.content');
  if (content) { content.style.overflow = ''; content.style.height = ''; }
});

function gotoPage(id, el) {
  if (typeof canAccessPage === 'function' && !canAccessPage(id)) {
    showAccessDenied();
    return;
  }
  const currentPage = document.querySelector('.page.active')?.id;
  // 사원 편집 중 다른 페이지로 이동 시 경고
  if(currentPage === 'page-employees' && id !== 'employees' && empFormDirty) {
    const jp = LANG==='JP';
    if(!confirm(jp?'保存されていない従業員情報があります。このまま移動しますか？':'저장되지 않은 사원 정보가 있습니다. 이동하시겠습니까?')) return;
    empFormDirty = false;
  }
  // 급여명세에서 다른 페이지로 이동 시 미저장 경고
  if(currentPage === 'page-payroll' && id !== 'payroll' && payrollDirty) {
    const jp = LANG==='JP';
    const msg = jp
      ? '保存されていない給与データがあります。このまま移動しますか？'
      : '저장되지 않은 급여 데이터가 있습니다. 이동하시겠습니까?';
    if(!confirm(msg)) return;
    // 경고 무시하고 이동 선택 — 미저장 내용 파기
    payrollDirty = false;
    const saveBtn = document.getElementById('btn-save');
    if(saveBtn) { saveBtn.style.background = ''; saveBtn.style.borderColor = ''; }
  }

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-'+id).classList.add('active');
  if(el) el.classList.add('active');
  else {
    const sideNav = document.querySelector(`.nav-item[data-page="${id}"]`);
    if(sideNav) sideNav.classList.add('active');
  }
  const titles = {payroll:{JP:'給与明細',KR:'급여 명세'},history:{JP:'支給履歴',KR:'지급 이력'},employees:{JP:'従業員管理',KR:'사원 관리'},rates:{JP:'保険料率設定',KR:'보험료율 설정'},annual:{JP:'賃金台帳',KR:'임금 대장'},gas:{JP:'データ管理',KR:'데이터 관리'},notifications:{JP:'通知',KR:'알림'}};
  const t = titles[id];
  if(t) document.getElementById('topbar-title').textContent = t[LANG];
  const isPayroll = id === 'payroll';
  document.getElementById('btn-save').style.display = isPayroll ? '' : 'none';
  const _paidBtn = document.getElementById('btn-mark-paid');
  if (_paidBtn) _paidBtn.style.display = isPayroll ? '' : 'none';
  if(id==='payroll') { loadPayrollForm(); renderPaidBtn(); }
  if(id==='history') { try { buildHistEmpSel(); renderHistory(); } catch(e) { console.error('history render error:', e); } }
  if(id==='employees') renderEmpList();
  if(id==='rates') renderRatesPage();
  if(id==='annual') { try { buildAnnualYearSel(); buildAnnualEmpSel(); renderAnnual(); } catch(e) { console.error('annual render error:', e); } }
  if(id==='gas') openGasModal();
  if(id==='notifications') renderNotificationsPage();
}

function resetLocalData() {
  const jp = LANG === 'JP';
  const msg1 = jp
    ? 'ローカルデータを初期化しますか？\nこの操作は元に戻せません。'
    : '로컬 데이터를 초기화하시겠습니까?\n이 작업은 되돌릴 수 없습니다.';
  const msg2 = jp
    ? '本当に初期化しますか？\nブラウザのすべてのキャッシュデータが削除されます。'
    : '정말로 초기화하시겠습니까?\n브라우저의 모든 캐시 데이터가 삭제됩니다.';
  if (!confirm(msg1)) return;
  if (!confirm(msg2)) return;

  // kyuyo_ 접두사 키 전체 삭제 (lang, auth 제외)
  const keepKeys = new Set([LS.lang, AUTH_SESS_KEY, AUTH_ID_KEY]);
  Object.keys(localStorage)
    .filter(k => k.startsWith('kyuyo_') && !keepKeys.has(k))
    .forEach(k => localStorage.removeItem(k));

  // 사원 편집 폼 초기화 (이전 데이터가 화면에 남지 않도록)
  empFormDirty = false;
  cancelEmpForm();

  // 상태 변수 초기화
  employees = [];
  deletedEmpIds = [];
  gasDeletedEmpIds = [];
  showResigned = false;
  rateHistory = [
    { from:'2024-03', kenko:9.98, kaigo:1.60, kodomo:0.00, nenkin:18.30, koyo:0.60 },
    { from:'2024-04', kenko:9.98, kaigo:1.60, kodomo:0.00, nenkin:18.30, koyo:0.60 },
    { from:'2025-03', kenko:9.91, kaigo:1.59, kodomo:0.00, nenkin:18.30, koyo:0.60 },
    { from:'2025-04', kenko:9.91, kaigo:1.59, kodomo:0.00, nenkin:18.30, koyo:0.55 },
    { from:'2026-03', kenko:9.85, kaigo:1.62, kodomo:0.00, nenkin:18.30, koyo:0.55 },
    { from:'2026-04', kenko:9.85, kaigo:1.62, kodomo:0.23, nenkin:18.30, koyo:0.50 },
  ];
  currentEmpIdx = -1;

  saveRateHistory();
  rerenderAll();
  showToast(jp ? 'ローカルデータを初期化しました' : '로컬 데이터를 초기화했습니다', 's');
}

// 전체 화면 갱신 — 언어 전환·데이터 초기화 등 전역 상태 변경 후 호출
function rerenderAll() {
  renderEmpSelect();
  renderEmpList();
  renderMonthTabs();
  applyRatesForYM(currentYear, currentMonth);
  loadPayrollForm();
  updateRatesDisplay();
  renderRatesPage();
  checkRateBanner();
  try { buildHistEmpSel(); renderHistory(); } catch(e) {}
  try { buildAnnualYearSel(); buildAnnualEmpSel(); renderAnnual(); } catch(e) {}
  updateGasStatus();
  recalc();
}

// 구버전 급여 localStorage 키 마이그레이션
// kyuyo_p_1_2026_5 → kyuyo_p_0001_2026_5 형태로 일괄 변환
function migratePayrollKeys() {
  try {
    employees.forEach(emp => {
      const paddedNo = String(emp.no).padStart(4, '0');
      const numericNo = String(parseInt(paddedNo, 10)); // "0001" → "1"
      if(paddedNo === numericNo) return; // 패딩이 이미 같으면 스킵
      const oldPrefix = `kyuyo_p_${numericNo}_`;
      const newPrefix = `kyuyo_p_${paddedNo}_`;
      // 하드코딩된 연도 범위 대신 실제 존재하는 키를 스캔
      const toMigrate = [];
      for(let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if(k && k.startsWith(oldPrefix)) toMigrate.push(k);
      }
      toMigrate.forEach(oldKey => {
        const newKey = newPrefix + oldKey.slice(oldPrefix.length);
        if(!localStorage.getItem(newKey)) localStorage.setItem(newKey, localStorage.getItem(oldKey));
        localStorage.removeItem(oldKey);
      });
    });
  } catch(e) {}
}

